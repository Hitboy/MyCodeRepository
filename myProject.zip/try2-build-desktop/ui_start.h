/********************************************************************************
** Form generated from reading UI file 'start.ui'
**
** Created: Sun Jun 17 10:05:01 2012
**      by: Qt User Interface Compiler version 4.7.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_START_H
#define UI_START_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_start
{
public:
    QPushButton *Button_open;
    QPushButton *Button_close;

    void setupUi(QDialog *start)
    {
        if (start->objectName().isEmpty())
            start->setObjectName(QString::fromUtf8("start"));
        start->resize(400, 145);
        Button_open = new QPushButton(start);
        Button_open->setObjectName(QString::fromUtf8("Button_open"));
        Button_open->setEnabled(true);
        Button_open->setGeometry(QRect(30, 40, 121, 41));
        Button_close = new QPushButton(start);
        Button_close->setObjectName(QString::fromUtf8("Button_close"));
        Button_close->setGeometry(QRect(230, 40, 121, 41));

        retranslateUi(start);

        QMetaObject::connectSlotsByName(start);
    } // setupUi

    void retranslateUi(QDialog *start)
    {
        start->setWindowTitle(QApplication::translate("start", "Dialog", 0, QApplication::UnicodeUTF8));
        Button_open->setText(QApplication::translate("start", "\347\224\250system\346\211\223\345\274\200", 0, QApplication::UnicodeUTF8));
        Button_close->setText(QApplication::translate("start", "\345\205\263           \351\227\255", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class start: public Ui_start {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_START_H
